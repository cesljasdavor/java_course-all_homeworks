package hr.fer.java.zemris.hw02.collections;


/**
 * Klasa definira jednu jedinu metodu {@link #process(Object)}
 * 
 * @author Davor Češljaš
 */
public class Processor {
	
	
	/**
	 * Metoda obrađuje predani objekt
	 *
	 * @param value objekt koji se obrađuje
	 */
	public void process(Object value) {
		
	}

}
